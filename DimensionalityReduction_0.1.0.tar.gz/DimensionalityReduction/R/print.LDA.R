print.LDA <- function(x){
  cat('Variances:\n')
  print(x$vars1)
  cat('Linear Discriminants:\n')
  print(x$lds1)
}
