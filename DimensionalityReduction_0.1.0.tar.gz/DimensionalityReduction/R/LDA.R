
LDA<-function(data, explanatory, response, firstdiscriminant=1, seconddiscriminant=2){
  data <- cbind.data.frame(data[,explanatory],data[,response])
  Sw <- matrix(0,nrow=ncol(data)-1,ncol=ncol(data)-1)
  lev <- levels(data[,ncol(data)])
  for(i in 1:length(lev)){
    Sw <- Sw + (nrow(data[data[,ncol(data)]==lev[i], -ncol(data)]))*cov(data[data[,ncol(data)]==lev[i],-ncol(data)])
  }
  Sw <- round(Sw,2)
  means <- matrix(0, nrow=ncol(data)-1, ncol = length(lev))
  for(i in 1:length(lev)){
    means[,i]<-colMeans(data[data[,ncol(data)]==lev[i],-ncol(data)])
  }
  means<-round(means,2)
  Sb <- matrix(0,nrow=ncol(data)-1, ncol = ncol(data)-1)
  for(i in 1:length(lev)){
    Sb <- Sb + (nrow(data[data[,ncol(data)]==lev[i],-ncol(data)])-1)*((means[,i]-colMeans(data[,-ncol(data)]))%*%t(means[,i]-colMeans(data[,-ncol(data)])))
  }
  Sb <- round(Sb,2)
  discriminants <- eigen(solve(Sw)%*%Sb)
  lds <- round(discriminants$vectors, 2)
  vars <- round(discriminants$values, 2)
  colnames(lds) <- paste0('LD',seq_len(ncol(lds)))
  rownames(lds) <- colnames(data[, -ncol(data)])
  colnames(means) <- lev
  rownames(means) <- colnames(data[, -ncol(data)])
  scores <- as.matrix(data[,-ncol(data)]) %*% lds
  cluster <- data[,ncol(data)]
  b <- list(lds1 = lds, vars1 = vars, mean = means, sco = scores, clu = cluster,
            first.d = firstdiscriminant, second.d=seconddiscriminant)
  class(b) <- 'LDA'
  b
}
