print.summary.PCA <- function(x){
  cat('Importance of Components:\n')
  print(x$summ)
  cat('Recommended Components to use:\n')
  print(x$recc)
}
