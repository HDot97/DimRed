print.PCA <- function(x){
  cat('Variances:\n')
  print(x$vars)
  cat('Principal Components:\n')
  print(x$comps)
}
