summary.PCA <- function(x){
  summ <- round(x$summ, 2)
  a <- list(summary = summ, recc = x$recc,var=x$var)
  class(a) <- 'summary.PCA'
  a
}
plot(iris)
