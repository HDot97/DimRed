plot.PCA <- function(x){
  plot(x$sco[,x$first.p]/max(abs(x$sco[,x$first.p])),
       x$sco[,x$second.p]/max(abs(x$sco[,x$second.p])), ylim=c(-1,1), xlim=c(-1,1),
       pch=20, col=x$cluster.p, xlab = paste0('PC',x$first.p), ylab=paste0('PC',x$second.p),
       main=paste('Bi','Plot','of',paste0('PC',x$first.p),'and',paste0('PC',x$second.p)))
  arrows(0, 0, x$comps[,x$first.p],x$comps[,x$second.p], col = 'red')
  text(x$comps[,x$first.p],x$comps[,x$second.p],labels=rownames(x$comps),
       col='blue')
}
