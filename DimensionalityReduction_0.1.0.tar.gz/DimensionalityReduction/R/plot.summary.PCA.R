plot.summary.PCA <- function(x){
  plot(x$summary[2,],type='l',ylim=c(0,1),ylab='Proportional and Cumulative Variances',xlab='Principal Components',
       main='Scree Plot')
  text(x$summary[2,],labels=x$summary[2,], col = 'blue')
  lines(x$summary[3,], col = 'black')
  text(x$summary[3,],labels=x$summary[3,],col='red')
  abline(a=x$var,b=0)
}
