plot.LDA <- function(x){
  plot(x$sco[,x$first.d],x$sco[,x$second.d],col=as.factor(x$clu), pch=20,
       xlab = paste('Linear Discriminant', x$first.d),
       ylab = paste('Linear Discriminant', x$second.d),
       main=paste('Bi','Plot','of',paste0('LD',x$first.d),'and',paste0('LD',x$second.d)))
}
