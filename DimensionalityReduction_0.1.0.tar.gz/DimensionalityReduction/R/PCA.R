PCA <- function(data,
                variables = c(),
                scale = FALSE,
                variance = 1,
                firstcomponent=1,
                secondcomponent=2,
                clustercm=0){
  x <- data[, clustercm]
  data <- data[, variables]
  eigendecomp <- if(scale == TRUE){
    eigen(cor(data))
  }else{
    eigen(cov(data))
  }
  variances <- round(eigendecomp$values, 2)
  components <- round(eigendecomp$vectors, 2)
  colnames(components) <- paste0('PC',seq_len(ncol(components)))
  rownames(components) <- colnames(data)
  summ <- rbind(sqrt(variances),
                variances/sum(variances),
                cumsum(variances/sum(variances)))
  colnames(summ) <- paste0('PC',seq_len(ncol(summ)))
  rownames(summ) <- c('Standard Deviations', 'Variance Proportion', 'Variance Cumulative Proportion')
  rec <- c()
  for(i in 1:ncol(components)){
    if(cumsum(variances/sum(variances))[i] <= variance){
      rec[i] <- paste0('PC',i)
    }
  }
  loadings <- if(scale == TRUE){
    scale(data)%*%components
  }else{
    scale(data,scale=FALSE)%*%components
  }
  clu <- if(clustercm==0){
    rep(1,nrow(data))
  }else{
    x
  }
  a <- list(vars = variances, comps = components, summary = summ, recc = rec, var = variance,
            scores = round(loadings,2), first.p = firstcomponent, second.p=secondcomponent,
            cluster.p = clu)
  class(a) <- 'PCA'
  a
}
