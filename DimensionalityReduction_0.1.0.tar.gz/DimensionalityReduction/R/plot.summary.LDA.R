plot.summary.LDA <- function(x){
  plot(x$varprop[1,], type = 'n',
       ylab = 'Cumulative Variance', xlab = 'Linear Discriminants',
       ylim=c(0,1), main = 'Scree Plot')
  lines(x$varprop[1,], col = 'black')
  lines(x$varprop[3,], col = 'black')
  text(x$varprop[1,],labels=x$varprop[1,],col='blue')
  text(x$varprop[3,],labels=x$varprop[3,],col='red')
}
