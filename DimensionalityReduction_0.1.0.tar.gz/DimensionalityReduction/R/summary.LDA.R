summary.LDA <- function(x){
  a <- rbind(x$vars1/sum(x$vars1),
             sqrt(x$vars1),
             cumsum(x$vars1/sum(x$vars1)))
  b <- x$mean
  colnames(a) <- paste0('LD', seq_len(ncol(a)))
  rownames(a) <- c('Proportion of Variance', 'Standard Deviation', 'Cumulative Variance')
  b <- list(varprop = round(a,2),
            mn = round(b,2))
  class(b) <- 'summary.LDA'
  b
}
