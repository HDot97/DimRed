print.summary.LDA <- function(x){
  cat('Group Means:\n')
  print(x$mn)
  cat('Importance of Discriminants:\n')
  print(x$varprop)
}
